import React, { Component } from "react";
import { Box } from "./Components/Box";
import FirstPage from "./Pages/FirstPage";
import FourthPage from "./Pages/FourthPage";
import PageThree from "./Pages/PageThree";
import SecondPage from "./Pages/SecondPage";

interface State {
  part: number;
  selected: string;
}
export default class App extends Component<{}, State> {
  state: State = {
    part: 1,
    selected: "",
  };

  goNext = () => {
    this.setState({ part: this.state.part + 1 });
  };

  goNextValue = (e: any) => {
    this.setState({ selected: e });
    this.setState({ part: this.state.part + 1 });
  };

  goBack = () => {
    this.setState({ part: this.state.part - 1 });
  };

  render() {
    return (
      <>
        <Box center>
          <Box p={40}>
            <>
              {this.state.part === 1 && (
                <FirstPage goNext={this.goNext}></FirstPage>
              )}
              {this.state.part === 2 && (
                <SecondPage goNext={this.goNextValue}></SecondPage>
              )}
              {this.state.part === 3 && (
                <PageThree
                  selected={this.state.selected}
                  goNext={this.goNext}
                ></PageThree>
              )}
              {this.state.part === 4 && (
                <FourthPage goNext={this.goNextValue}></FourthPage>
              )}
            </>
          </Box>
        </Box>
      </>
    );
  }
}

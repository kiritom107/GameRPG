export const colors = {
       green: '#18818b',
  black: '#3b3b3b',
  white: '#ffffff',
  grey: '#a3a1aa',
  lightGrey: '#F2F2F3',
   }
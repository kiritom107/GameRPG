export const buttons = {
  borderRadius14px: "14px",
  padding8px: "8px",
  padding16px: "16px",
  padding12px: "12px",
  padding24px: "24px",
  padding32px: "32px",
  padding40px: "40px",
  gap4px: "4px",
  gap8px: "8px",
};

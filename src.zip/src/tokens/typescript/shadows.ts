export const shadows = {
       dropLightColor: '#262a4824',
  dropLightType: 'dropShadow',
  dropLightX: '4',
  dropLightY: '8',
  dropLightBlur: '16',
  dropLightSpread: '0',
   }
import styled from "@emotion/styled";

import { array } from "prop-types";
import React, { Component } from "react";
import { Box } from "../Components/Box";
import { Button } from "../Components/Button";
import { Icons } from "../Components/Icons";
import { Text } from "../Components/Text";

interface Props {
  goNext: any;
}
export default class FirstPage extends Component<Props> {
  render() {
    return (
      <Box
        style={{ backgroundColor: "lightblue", maxWidth: 375, maxHeight: 812 }}
        width={375}
        height={812}
        ph={46}
        pt={46}
      >
        <Box style={{ justifyContent: "space-between" }} vcenter row mb={124}>
          <Icons.trysvg1></Icons.trysvg1>
          {/* <Box style={{ itemSpacing: 'space-between' }}></Box> */}
          <Button variant="white" size="small">
            Iscriviti
          </Button>
        </Box>
        <Box center>
          <Text
            color={"black"}
            style={{ marginBottom: 8 }}
            weight={700}
            fontSize={16}
          >
            Benvenut* in
          </Text>
          <MiniBox>
            <Icons.trysvg1
              style={{ minWidth: 190, minHeight: 70 }}
            ></Icons.trysvg1>
          </MiniBox>
          <Text
            style={{ textAlign: "center" }}
            color={"black"}
            weight={700}
            fontSize={16}
          >
            Asters è un nuovo social media manager nato per semplificare il
            vostro lavoro
          </Text>
        </Box>
        <Box center mt={72}>
          <Button width={329} height={52} onClick={this.props.goNext}>
            Scopri Asters
          </Button>
        </Box>
      </Box>
    );
  }
}

const MiniBox = styled(Box)`
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  padding: 16px 32px;
  min-width: 232px;
  min-height: 82px;
  margin-bottom: 56px;
  background: #ffffff;

  box-shadow: 4px 8px 16px rgba(38, 42, 72, 0.14);
  border-radius: 14px;
`;

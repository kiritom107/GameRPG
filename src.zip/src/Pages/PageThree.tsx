import styled from "@emotion/styled";
import { Box } from "../Components/Box";
import { Button } from "../Components/Button";
import { Icons } from "../Components/Icons";
import { Text } from "../Components/Text";

import React, { Component } from "react";

interface Props {
  goNext: any;
  selected: string;
}
export default class PageThree extends Component<Props> {
  render() {
    return (
      <Box
        style={{ backgroundColor: "lightblue" }}
        width={375}
        height={812}
        ph={16}
        pt={46}
      >
        <Box style={{ justifyContent: "space-between" }} vcenter row>
          <Icons.trysvg1></Icons.trysvg1>
          <Button variant="white" size="small">
            Iscriviti
          </Button>
        </Box>

        <MiniBox center mt={186}>
          <Text
            weight={500}
            fontSize={16}
            style={{ textAlign: "center", marginBottom: 8 }}
          >
            Siamo pronti! 🔥 <br /> Stai per vivere l'esperienza nella <br />
            creazione di un post grazie alla
            <br /> straordinaria potenza dell'intelligenza <br /> artificiale di
            Asters!
            <br /> Ciò che stai per vedere è una demo <br /> guidata
            dimostrativa. <br />
            Segui le semplici istruzioni a schermo <br />e buona creazione 🚀
          </Text>
        </MiniBox>

        <Selectble onClick={() => this.props.goNext()}>
          {" "}
          Non vedo l'ora, partiamo!{" "}
        </Selectble>
      </Box>
    );
  }
}

const Selectble = styled(Button)`
  /* CTA */
  /* Auto layout */
  margin-top: 16px;
  display: flex;
  flex-direction: column;
  align-items: center;
  padding: 16px;
  background: #18818b;
  /* drop_light */
  box-shadow: 4px 8px 16px rgba(38, 42, 72, 0.14);
  border-radius: 14px;
  /* Inside auto layout */
  flex: none;
  order: 1;
  flex-grow: 0;
`;

const MiniBox = styled(Box)`
  display: flex;
  flex-direction: row;
  justify-content: center;
  align-items: flex-start;
  padding: 32px 24px;
  /* white */
  background: #ffffff;
  /* drop_light */
  box-shadow: 4px 8px 16px rgba(38, 42, 72, 0.14);
  border-radius: 14px;
`;

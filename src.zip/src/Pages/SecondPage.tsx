import styled from "@emotion/styled";

import React, { Component } from "react";
import { Box } from "../Components/Box";
import { Button } from "../Components/Button";
import { Icons } from "../Components/Icons";
import { Text } from "../Components/Text";

interface Props {
  goNext: any;
}
export default class SecondPage extends Component<Props> {
  info = [
    "Marketing & Comunicazione",
    "Sport & Benessere",
    "Industra & Seravizi",
    "Horeka & Turismo",
    "Vendita al dettaglio",
    "Marketing & Comunicazione",
  ];
  render() {
    return (
      <Box
        style={{ backgroundColor: "lightblue" }}
        width={375}
        height={812}
        ph={16}
        pt={46}
      >
        <Box style={{ justifyContent: "space-between" }} vcenter row mb={35}>
          <Icons.trysvg1></Icons.trysvg1>
          {/* <Box style={{ itemSpacing: 'space-between' }}></Box> */}
          <Button variant="white" size="small">
            Iscriviti
          </Button>
        </Box>

        <MiniBox center>
          <Text
            weight={700}
            fontSize={16}
            style={{ textAlign: "center", marginBottom: 8 }}
          >
            Prima di cominciare,<br></br> puoi dirci qual è il tuo settore?
          </Text>
          <Text weight={400} fontSize={14} style={{ textAlign: "center" }}>
            Questa informazione ci servirà per pesonalizzare al meglio la tua
            esperienza
          </Text>
        </MiniBox>

        {this.info.map((e) => (
          <Selectble onClick={() => this.props.goNext(e)}>{e}</Selectble>
        ))}
      </Box>
    );
  }
}

const Selectble = styled(Button)`
  /* CTA */
  /* Auto layout */
  margin-top: 16px;
  display: flex;
  flex-direction: column;
  align-items: center;
  padding: 16px;
  background: #18818b;
  /* drop_light */
  box-shadow: 4px 8px 16px rgba(38, 42, 72, 0.14);
  border-radius: 14px;
  /* Inside auto layout */
  flex: none;
  order: 1;
  flex-grow: 0;
`;

const MiniBox = styled(Box)`
  padding: 24px;
  width: auto;
  height: 152px;
  /* white */
  background: #ffffff;
  /* drop_light */
  box-shadow: 4px 8px 16px rgba(38, 42, 72, 0.14);
  border-radius: 14px;
`;

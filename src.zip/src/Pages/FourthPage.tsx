import styled from "@emotion/styled";

import React, { Component } from "react";
import AppStore from "../Components/AppStore";
import { Box } from "../Components/Box";
import { Button } from "../Components/Button";
import { Icons } from "../Components/Icons";
import { Text } from "../Components/Text";
import { TextArea } from "../Components/TextArea";
import { ZoomedContainer } from "../Components/ZoomedContainer";

interface Props {
  goNext: any;
}

interface State {
  cliked: boolean;
  selected: string;
  step: number;
  value: string;
  textValue: string;
}

const typeGeneration = [
  { key: "visibility", value: "Visibilità" },
  { key: "event", value: "Evento / Festività" },
  { key: "utility", value: "Info Utili" },
  { key: "promo", value: "Promozione / Sconto" },
  { key: "contest", value: "Contest / Give Away" },
];

const InfoTexts = [
  "Per prima cosa premi il box testo evidenziato. In questa demo guidata abbiamo scelto noi per te alcune parole chiave da dare in pasto alla nostra intelligenza artificiale.",
  'Ci siamo, ora tocca a te! 🖐 Premi il tasto "Obiettivo" e seleziona l obiettivo del post che stai creando.',
  'Ottima scelta 😉 È arrivato il momento di vedere con i tuoi occhi la potenza e velocità della nostra intelligenza artificiale 👀 Premi il tasto "Genera" e libera la magia!',
  "La nostra intelligenza artificiale sta creando i testi per te 🧐 Attendi qualche secondo... \n <Icona aster>",
  "I testi per il tuo post sono pronti! 🤩 \n Scrolla qui sotto ⬇️ \n Scegli il testo che più fa per te! 👀",
];

const Choises = [
  `Il mio nuovo #iPhone è arrivato oggi e sono super emozionata! 📱💕 Non vedo l'ora di iniziare a usarlo e sperimentare tutte le nuove funzionalità. Non vedo l'ora di scattare foto mozzafiato e realizzare video in 4K. Sarò anche in grado di fare chiamate faccia a faccia con FaceTime e sbloccare il telefono grazie alla nuova impronta digitale. Sono così entusiasta del mio nuovo telefono!`,

  `Oggi ho comprato il mio #nuovo #iPhone e sono super felice! 😍L'ho scelto perché:
-Ha un design elegante e funzionale.
-È dotato di ultima generazione di processore, fotocamera e connettività.
-Offre una buona autonomia della batteria.
Non vedo l'ora di testare tutte le nuove funzionalità!`,
  `Sono super eccitato per il mio #nuovo #iPhone che ho acquistato oggi! 📱 Non vedo l'ora di provare tutte le nuove funzionalità e scattare foto e video di qualità superiore. 😍`,
];
const imgPath = ["./Img/img1", "./Img/img2", "./Img/img3", "./Img/img4"];

function delay(time: number | undefined) {
  return new Promise((resolve) => setTimeout(resolve, time));
}
export default class FourthPage extends Component<Props, State> {
  state: State = {
    cliked: false,
    selected: "Obbiettivo",
    step: 0,
    value: "Oggi ho comprato il mio nuovo iPhone",
    textValue: "",
  };

  openMediaModal = () => {
    AppStore.openModal({
      width: 500,
      id: "media-modal-selector",

      body: (
        <ZoomedContainer
          center
          flex
          style={{
            position: "relative",
            padding: "16px 12px",
            maxWidth: 1800,
            opacity: "none",
          }}
        >
          <Box width={302} height={74} bgPrimaryColor center>
            <Text weight={500} fontSize={16}>
              Scegli un obbiettivo per il tuo post
            </Text>
          </Box>
          {typeGeneration.map((e) => (
            <Selectble
              onClick={() => {
                this.setState({ selected: e.key, step: 2 });
                AppStore.closeModal("media-modal-selector");
              }}
            >
              {e.value}
            </Selectble>
          ))}
        </ZoomedContainer>
        // <Text>ciaop</Text>
      ),

      style: {
        backgroundColor: "transparent",
        minWidth: 302,
      },
    });
  };

  openImgModal = () => {
    AppStore.openModal({
      width: 9000,
      id: "media-modal-dasdas",

      body: (
        <ZoomedContainer
          center
          flex
          style={{
            position: "relative",
            padding: "16px 12px",
            maxWidth: 1800,
            opacity: "none",
          }}
        >
          <Box pt={200}>
            <Box row>
              <Box>
                <Box>
                  <img
                    style={{
                      height: 200, // 100% sul imaggine
                      width: 300,
                    }}
                    // src={require("./Img/img1.png")}
                    // src={img}
                  />
                </Box>
              </Box>
              <Box>
                <img
                  style={{
                    height: 200, // 100% sul imaggine
                    width: 300,
                  }}
                  //   src={require("./Img/img1.png")}
                  // src={img}
                />
              </Box>
            </Box>

            <Box row>
              <Box>
                <Box>
                  <img
                    style={{
                      height: 200, // 100% sul imaggine
                      width: 300,
                    }}
                    // src={require("./Img/img1.png")}
                    // src={img}
                  />
                </Box>
              </Box>
              <Box>
                <img
                  style={{
                    height: 200, // 100% sul imaggine
                    width: 300,
                  }}
                  //   src={require("./Img/img1.png")}
                  // src={img}
                />
              </Box>
            </Box>
          </Box>
        </ZoomedContainer>
        // <Text>ciaop</Text>
      ),

      style: {
        minWidth: 302,
      },
    });
  };

  // addText = async () => {
  //   const leght = this.state.value.length
  //   let i = 0
  //   while (i < 10) {
  //     await this.while(1)
  //   }
  // }

  // while = async (i) => {
  //   await setTimeout(() => {
  //     console.log(this.state.value.slice(i))
  //     this.setState({ textValue: this.state.value.slice(0, i) })
  //   }, 9000)
  // }

  render() {
    return (
      <Box
        style={{ backgroundColor: "lightblue" }}
        width={375}
        height={812}
        ph={16}
        pt={46}
        scroll
      >
        <Box style={{ justifyContent: "space-between" }} vcenter row mb={35}>
          <Icons.trysvg1></Icons.trysvg1>
          {/* <Box style={{ itemSpacing: 'space-between' }}></Box> */}
          <Button variant="white" size="small">
            Iscriviti
          </Button>
        </Box>

        <MiniBox p={24}>
          <Box center>
            <Text
              weight={700}
              fontSize={16}
              style={{ marginLeft: 108, marginRight: 108 }}
            >
              Crea Post
            </Text>
          </Box>
          <Text weight={700} fontSize={16}>
            Il tuo testo
          </Text>
          <FlexTextArea
            onClick={() =>
              this.setState({ textValue: this.state.value, step: 1 })
            }
            id="text-area-create-post"
            bgcolor={"#F2F2F3"}
            bgcoloractive={"#F2F2F3"}
            borderactivecolor={"#D8DCE0"}
            bordercolor="{'transparent'}"
            borderwidth={"1px"}
            height={122}
            value={this.state.textValue}
            placeholder="Inserisci qui il testo del tuo post"
          />

          <Box row>
            <GenerationButton
              size="small"
              variant="white"
              disabled={this.state.step !== 2}
              onClick={() => {
                this.setState({ step: 3 });
                delay(4000).then(() => this.setState({ step: 4 }));
              }}
            >
              Genera
            </GenerationButton>

            <SelectModalButton
              ml={24}
              mt={4}
              style={{
                backgroundColor: this.state.step === 0 ? "#f2f2f3 " : "#18818B",
              }}
            >
              <Text
                color={this.state.step === 0 ? "black" : "white"}
                onClick={() => {
                  this.state.step === 0 ? null : this.openMediaModal();
                }}
              >
                {this.state.selected}
              </Text>
              <Icons.trysvg2></Icons.trysvg2>
            </SelectModalButton>
          </Box>
        </MiniBox>

        <InfoBox mt={24}>
          <Text weight={500} fontSize={16} style={{ textAlign: "center" }}>
            {InfoTexts[this.state.step]}
          </Text>
        </InfoBox>

        {this.state.step == 4 &&
          Choises.map((e, index) => (
            <Box>
              <InfoBox mt={24}>
                <Text
                  weight={500}
                  fontSize={16}
                  style={{ textAlign: "center" }}
                >
                  {e}
                </Text>
              </InfoBox>
              <Selectble onClick={() => this.openImgModal()}>
                Voglio questo!
              </Selectble>
            </Box>
          ))}
      </Box>
    );
  }
}

const GenerationButton = styled(Button)`
  width: 133.5px;
  height: 42px;
`;

const MiniBox = styled(Box)`
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  padding: 24px;
  gap: 8px;
  width: 339px;
  height: 297px;
  background: #ffffff;

  box-shadow: 4px 8px 16px rgba(38, 42, 72, 0.14);
  border-radius: 14px;
`;
const FlexTextArea = styled(TextArea)`
  line-height: 24pt !important;
`;
const InfoBox = styled(Box)`
  /* Auto layout */

  display: flex;
  flex-direction: column;
  align-items: center;
  padding: 24px;
  gap: 8px;

  width: 339px;

  /* white */

  background: #ffffff;
  /* drop_light */

  box-shadow: 4px 8px 16px rgba(38, 42, 72, 0.14);
  border-radius: 14px;
`;
const SelectModalButton = styled(Box)`
  display: flex;
  flex-direction: row;
  justify-content: center;
  align-items: center;
  padding: 8px;
  gap: 4px;

  width: 133.5px;
  height: 40px;

  border-radius: 14px;

  /* Inside auto layout */

  flex: none;
  order: 1;
  flex-grow: 1;
  z-index: 0;
`;

const Selectble = styled(Button)`
  /* CTA */
  /* Auto layout */
  margin-top: 16px;

  min-width: 302px;
  display: flex;
  flex-direction: column;
  align-items: center;
  padding: 16px;
  background: #18818b;
  /* drop_light */
  box-shadow: 4px 8px 16px rgba(38, 42, 72, 0.14);
  border-radius: 14px;
  /* Inside auto layout */
  flex: none;
  order: 1;
  flex-grow: 0;
`;

import React, { Component } from "react";
import styled from "@emotion/styled";
import { Button } from "./Button";

import { buttons } from "../tokens/typescript/buttons";
import { colors } from "../tokens/typescript/colors";
import { typography } from "../tokens/typescript/typography";
import { Box } from "./Box";

interface Props {
  content?: string;
}
export default class BoxText extends Component<Props> {
  render() {
    return <BoxMessage>{this.props.content}</BoxMessage>;
  }
}

const BoxMessage = styled(Box)`
  padding-top: ${buttons.padding32px};
  padding-bottom: ${buttons.padding32px};
  padding-left: ${buttons.padding24px};
  padding-right: ${buttons.padding24px};

  background-color: ${colors.white};
  color: ${colors.black};

  width: 339px;

  border-radius: ${buttons.borderRadius14px};
  font-family: ${typography.textAiFontFamily};
  font-size: ${typography.textAiFontSize};
  font-weight: ${typography.textAiFontWeight};
  line-height: ${typography.textAiLineHeight};
`;

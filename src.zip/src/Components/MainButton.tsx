import React, { Component } from "react";
import styled from "@emotion/styled";
import { Button } from "./Button";

import { buttons } from "../tokens/typescript/buttons";
import { colors } from "../tokens/typescript/colors";
import { typography } from "../tokens/typescript/typography";

interface Props {
  name?: any;
  variant?: any;
}
export default class MainButton extends Component<Props> {
  render() {
    return (
      <ButtonMain variant={this.props.variant}>
        {this.props.name as any}{" "}
      </ButtonMain>
    );
  }
}

const ButtonMain = styled(Button)<Props>`
  ${({ variant }) =>
    variant === "Main" &&
    ` padding-top: ${buttons.padding16px};
      padding-bottom: ${buttons.padding16px};
      background-color: ${colors.green};
      color: ${colors.white};
      border-radius: ${buttons.borderRadius14px};
      width: 339px;
      font-family: ${typography.textButtonFontFamily};
      font-size: ${typography.textButtonFontSize};
      font-weight: ${typography.textButtonFontWeight};
      line-height: ${typography.textButtonLineHeight};    
    `}
  ${({ variant }) =>
    variant === "cta" &&
    ` padding-top: ${buttons.padding8px};
      padding-bottom: ${buttons.padding8px};
      padding-right : ${buttons.padding16px};
      padding-left : ${buttons.padding16px};
      background-color: ${colors.white};
      color: ${colors.black};
      border-radius: ${buttons.borderRadius14px};
      font-family: ${typography.titleFontFamily};
      font-size: ${typography.titleFontSize};
      font-weight: ${typography.titleFontWeight};
      line-height: ${typography.titleLineHeight}; 
      `}
`;
